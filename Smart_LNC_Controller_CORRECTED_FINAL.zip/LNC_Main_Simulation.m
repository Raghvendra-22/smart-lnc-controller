%% SMART LNC CONTROLLER - CORRECTED FINAL MODEL
% Hosting Capacity Improvement in an Unbalanced LV Distribution Feeder
%
% Three-bus representative radial feeder
% Baseline vs Local Node Controller (LNC)
%
% IMPORTANT CONTROL CONVENTION:
%   Qpv > 0 : inverter injects reactive power
%   Qpv < 0 : inverter absorbs reactive power
%
% Therefore:
%   High voltage  -> Qpv < 0 -> reactive absorption -> voltage reduction
%   Low voltage   -> Qpv > 0 -> reactive injection -> voltage support
%
% This is a representative/test feeder, NOT an actual KSEB feeder.

clear;
clc;
close all;

%% 1. SYSTEM PARAMETERS
Vmax_limit = 1.05;       % pu
Vmin_limit = 0.95;       % pu
VUF_limit  = 2.0;        % %

nbus = 3;
nph  = 3;

Rline = 0.05;            % pu
Xline = 0.02;            % pu
Zline = Rline + 1j*Xline;

%% 2. LOAD CONFIGURATION
% Rows = buses, columns = phases [A B C]

Pload = [
    0.12  0.08  0.06;
    0.10  0.10  0.07;
    0.08  0.09  0.08
];

PFload = 0.95;
Qload = Pload .* tan(acos(PFload));

%% 3. PV DISTRIBUTION
PVcoeff = [
    0.15  0.20  0.10;
    0.20  0.10  0.15;
    0.15  0.15  0.20
];

%% 4. PV SWEEP
PV_levels = 0:0.05:4.0;
N = numel(PV_levels);

%% 5. STORAGE
Vmax_base = zeros(1,N);
Vmin_base = zeros(1,N);
VUF_base  = zeros(1,N);
PI_base   = zeros(1,N);

Vmax_LNC = zeros(1,N);
Vmin_LNC = zeros(1,N);
VUF_LNC  = zeros(1,N);
PI_LNC   = zeros(1,N);

%% 6. LNC PHASE-BALANCING ACTION
% Load is shifted without changing total three-phase load.

Pload_LNC = Pload;

% Bus 3: A -> C
Pload_LNC(3,1) = Pload_LNC(3,1) - 0.03;
Pload_LNC(3,3) = Pload_LNC(3,3) + 0.03;

% Bus 2: A -> B
Pload_LNC(2,1) = Pload_LNC(2,1) - 0.02;
Pload_LNC(2,2) = Pload_LNC(2,2) + 0.02;

Qload_LNC = Pload_LNC .* tan(acos(PFload));

%% 7. LNC VOLT-VAR SETTINGS
% Kq controls the strength of the Volt-VAR response.
Kq = 1.5;

% Deadband around 1.0 pu.
Vdead_low  = 0.98;
Vdead_high = 1.02;

% Maximum inverter reactive power capability:
% |Qpv| <= Qcap_ratio * Ppv
Qcap_ratio = 0.80;

% Iteration settings for local voltage control.
control_iterations = 30;
relaxation = 0.40;

fprintf('\nSMART LNC CONTROLLER - CORRECTED SIMULATION\n');
fprintf('============================================\n');
fprintf('High V: reactive absorption (Qpv < 0)\n');
fprintf('Low V : reactive injection  (Qpv > 0)\n');

%% 8. PV PENETRATION SIMULATION
for k = 1:N

    PVlevel = PV_levels(k);
    Ppv = PVlevel .* PVcoeff;

    %% ---------------- BASELINE ----------------
    Pnet_base = Pload - Ppv;
    Qnet_base = Qload;

    [V_base,I_base] = feeder_powerflow(Pnet_base,Qnet_base,Zline);

    Vmax_base(k) = max(abs(V_base(:)));
    Vmin_base(k) = min(abs(V_base(:)));
    VUF_base(k)  = calculate_vuf(V_base);
    PI_base(k)   = calculate_phase_imbalance(I_base);

    %% ---------------- LNC ----------------
    Pnet_LNC = Pload_LNC - Ppv;

    % Start with unity power factor PV.
    Qpv_LNC = zeros(nbus,nph);

    % Iterative local Volt-VAR controller.
    for iter = 1:control_iterations

        Qnet_LNC = Qload_LNC - Qpv_LNC;

        [V_temp,~] = feeder_powerflow( ...
            Pnet_LNC,Qnet_LNC,Zline);

        Vmag = abs(V_temp);

        Qcmd = zeros(nbus,nph);

        % High voltage:
        % Qpv < 0 means the inverter absorbs reactive power.
        high_idx = Vmag > Vdead_high;
        Qcmd(high_idx) = ...
            -Kq .* Ppv(high_idx) .* ...
            (Vmag(high_idx) - Vdead_high) ./ ...
            (Vmax_limit - Vdead_high);

        % Low voltage:
        % Qpv > 0 means the inverter injects reactive power.
        low_idx = Vmag < Vdead_low;
        Qcmd(low_idx) = ...
             Kq .* Ppv(low_idx) .* ...
            (Vdead_low - Vmag(low_idx)) ./ ...
            (Vdead_low - Vmin_limit);

        % Apply inverter Q capability.
        Qcap = Qcap_ratio .* Ppv;
        Qcmd = max(-Qcap,min(Qcap,Qcmd));

        % Relaxation prevents control oscillation.
        Qnew = relaxation .* Qcmd + ...
               (1-relaxation) .* Qpv_LNC;

        if max(abs(Qnew(:)-Qpv_LNC(:))) < 1e-8
            Qpv_LNC = Qnew;
            break;
        end

        Qpv_LNC = Qnew;
    end

    % Final LNC power flow.
    Qnet_LNC = Qload_LNC - Qpv_LNC;

    [V_LNC,I_LNC] = feeder_powerflow( ...
        Pnet_LNC,Qnet_LNC,Zline);

    Vmax_LNC(k) = max(abs(V_LNC(:)));
    Vmin_LNC(k) = min(abs(V_LNC(:)));
    VUF_LNC(k)  = calculate_vuf(V_LNC);
    PI_LNC(k)   = calculate_phase_imbalance(I_LNC);
end

%% 9. HOSTING CAPACITY
valid_base = ...
    (Vmax_base <= Vmax_limit) & ...
    (Vmin_base >= Vmin_limit) & ...
    (VUF_base <= VUF_limit);

valid_LNC = ...
    (Vmax_LNC <= Vmax_limit) & ...
    (Vmin_LNC >= Vmin_limit) & ...
    (VUF_LNC <= VUF_limit);

if any(valid_base)
    HC_base = max(PV_levels(valid_base));
else
    HC_base = NaN;
end

if any(valid_LNC)
    HC_LNC = max(PV_levels(valid_LNC));
else
    HC_LNC = NaN;
end

if ~isnan(HC_base) && HC_base > 0 && ~isnan(HC_LNC)
    HC_improvement = 100*(HC_LNC-HC_base)/HC_base;
else
    HC_improvement = NaN;
end

fprintf('\nHOSTING CAPACITY RESULTS\n');
fprintf('------------------------\n');
fprintf('Baseline HC = %.2f pu\n',HC_base);
fprintf('LNC HC      = %.2f pu\n',HC_LNC);
fprintf('Improvement = %.2f %%\n',HC_improvement);

%% 10. FIGURE 1 - MAXIMUM VOLTAGE
figure('Name','Maximum Voltage vs PV Penetration');
plot(PV_levels,Vmax_base,'o-','LineWidth',1.5,'MarkerSize',4);
hold on;
plot(PV_levels,Vmax_LNC,'s-','LineWidth',1.5,'MarkerSize',4);
yline(Vmax_limit,'--','Voltage Limit','LineWidth',1.2);

xlabel('PV Penetration (pu)');
ylabel('Maximum Bus Voltage (pu)');
title('Maximum Voltage vs PV Penetration');
legend('Baseline','LNC','Limit','Location','northwest');
grid on;
xlim([0 4]);

%% 11. FIGURE 2 - MINIMUM VOLTAGE
figure('Name','Minimum Voltage vs PV Penetration');
plot(PV_levels,Vmin_base,'o-','LineWidth',1.5,'MarkerSize',4);
hold on;
plot(PV_levels,Vmin_LNC,'s-','LineWidth',1.5,'MarkerSize',4);
yline(Vmin_limit,'--','Lower Voltage Limit','LineWidth',1.2);

xlabel('PV Penetration (pu)');
ylabel('Minimum Bus Voltage (pu)');
title('Minimum Voltage vs PV Penetration');
legend('Baseline','LNC','Limit','Location','best');
grid on;
xlim([0 4]);

%% 12. FIGURE 3 - VUF
figure('Name','Voltage Unbalance vs PV Penetration');
plot(PV_levels,VUF_base,'o-','LineWidth',1.5,'MarkerSize',4);
hold on;
plot(PV_levels,VUF_LNC,'s-','LineWidth',1.5,'MarkerSize',4);
yline(VUF_limit,'--','VUF Limit','LineWidth',1.2);

xlabel('PV Penetration (pu)');
ylabel('Voltage Unbalance Factor (%)');
title('Voltage Unbalance vs PV Penetration');
legend('Baseline','LNC','Limit','Location','best');
grid on;
xlim([0 4]);

%% 13. FIGURE 4 - PHASE CURRENT IMBALANCE
figure('Name','Phase Current Imbalance');
plot(PV_levels,PI_base,'o-','LineWidth',1.5,'MarkerSize',4);
hold on;
plot(PV_levels,PI_LNC,'s-','LineWidth',1.5,'MarkerSize',4);

xlabel('PV Penetration (pu)');
ylabel('Phase Current Imbalance (%)');
title('Phase Current Imbalance vs PV Penetration');
legend('Baseline','LNC','Location','best');
grid on;
xlim([0 4]);

%% 14. FIGURE 5 - HOSTING CAPACITY
figure('Name','Hosting Capacity Comparison');
bar([HC_base HC_LNC]);
set(gca,'XTick',1:2,'XTickLabel',{'Baseline','LNC'});
ylabel('Hosting Capacity (pu)');
title('Hosting Capacity Comparison');
grid on;

%% 15. FIGURE 6 - END-BUS PHASE VOLTAGE
if ~isnan(HC_base)
    PV_test = HC_base;
else
    PV_test = 1.0;
end

Ppv_test = PV_test .* PVcoeff;

% Baseline
Pnet_b = Pload - Ppv_test;
Qnet_b = Qload;
[Vb,~] = feeder_powerflow(Pnet_b,Qnet_b,Zline);

% LNC
Pnet_l = Pload_LNC - Ppv_test;
Qpv_test = zeros(nbus,nph);

for iter = 1:control_iterations

    Qnet_l = Qload_LNC - Qpv_test;
    [Vtemp,~] = feeder_powerflow(Pnet_l,Qnet_l,Zline);
    Vmag = abs(Vtemp);

    Qcmd = zeros(nbus,nph);

    high_idx = Vmag > Vdead_high;
    Qcmd(high_idx) = ...
        -Kq .* Ppv_test(high_idx) .* ...
        (Vmag(high_idx)-Vdead_high) ./ ...
        (Vmax_limit-Vdead_high);

    low_idx = Vmag < Vdead_low;
    Qcmd(low_idx) = ...
         Kq .* Ppv_test(low_idx) .* ...
        (Vdead_low-Vmag(low_idx)) ./ ...
        (Vdead_low-Vmin_limit);

    Qcap = Qcap_ratio .* Ppv_test;
    Qcmd = max(-Qcap,min(Qcap,Qcmd));

    Qnew = relaxation .* Qcmd + ...
           (1-relaxation) .* Qpv_test;

    if max(abs(Qnew(:)-Qpv_test(:))) < 1e-8
        Qpv_test = Qnew;
        break;
    end

    Qpv_test = Qnew;
end

Qnet_l = Qload_LNC - Qpv_test;
[Vl,~] = feeder_powerflow(Pnet_l,Qnet_l,Zline);

figure('Name','End-Bus Phase Voltage Comparison');
bar([abs(Vb(end,:)); abs(Vl(end,:))]');
xlabel('Phase');
ylabel('Voltage (pu)');
set(gca,'XTick',1:3,'XTickLabel',{'A','B','C'});
legend('Baseline','LNC','Location','best');
title(sprintf('End-Bus Phase Voltage at PV = %.2f pu',PV_test));
grid on;

%% 16. SAVE NUMERICAL RESULTS
Results = table( ...
    PV_levels', ...
    Vmax_base', Vmax_LNC', ...
    Vmin_base', Vmin_LNC', ...
    VUF_base', VUF_LNC', ...
    PI_base', PI_LNC', ...
    'VariableNames',{ ...
    'PV_pu', ...
    'Vmax_Baseline','Vmax_LNC', ...
    'Vmin_Baseline','Vmin_LNC', ...
    'VUF_Baseline_percent','VUF_LNC_percent', ...
    'PhaseImbalance_Baseline_percent', ...
    'PhaseImbalance_LNC_percent'});

writetable(Results,'LNC_Simulation_Results.csv');

Summary = table(HC_base,HC_LNC,HC_improvement, ...
    'VariableNames',{'HC_Baseline_pu','HC_LNC_pu','Improvement_percent'});
writetable(Summary,'LNC_Hosting_Capacity_Summary.csv');

fprintf('\nFiles saved:\n');
fprintf('  LNC_Simulation_Results.csv\n');
fprintf('  LNC_Hosting_Capacity_Summary.csv\n');

%% END
