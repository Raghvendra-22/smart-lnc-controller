function PI = calculate_phase_imbalance(Ibranch)
% CALCULATE_PHASE_IMBALANCE
% Maximum phase-current magnitude spread across feeder sections.
%
% PI = (Imax - Imin) / Iavg * 100

Imag = abs(Ibranch);

PI_bus = zeros(size(Imag,1),1);

for b = 1:size(Imag,1)

    Iph = Imag(b,:);

    if mean(Iph) < 1e-12
        PI_bus(b) = 0;
    else
        PI_bus(b) = ...
            100*(max(Iph)-min(Iph))/mean(Iph);
    end
end

PI = max(PI_bus);

end
