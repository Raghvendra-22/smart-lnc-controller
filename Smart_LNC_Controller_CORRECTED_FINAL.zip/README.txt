SMART LNC CONTROLLER - CORRECTED MATLAB PACKAGE
================================================

Files
-----
1. LNC_Main_Simulation.m
2. feeder_powerflow.m
3. calculate_vuf.m
4. calculate_phase_imbalance.m

IMPORTANT CORRECTION
--------------------
The previous code used the wrong reactive-power sign for the high-voltage
condition.

Correct convention:
    Qpv > 0  = inverter reactive-power injection
    Qpv < 0  = inverter reactive-power absorption

Therefore:
    High voltage -> Qpv < 0 -> Qnet = Qload - Qpv increases
                  -> feeder absorbs reactive power
                  -> voltage is reduced.

The corrected controller uses a Volt-VAR droop/deadband response and
iterates the local control until the voltage response converges.

WHAT TO EXPECT
--------------
For increasing PV penetration, the intended physical result is:

    Baseline maximum voltage > LNC maximum voltage
    at sufficiently high PV penetration.

The LNC curve should therefore stay below the baseline curve after the
controller becomes active. The exact hosting-capacity values are produced
by the model and should NOT be hard-coded.

HOW TO RUN
----------
Place all four .m files in the same MATLAB folder.

Then run:
    LNC_Main_Simulation

The program produces six figures and:
    LNC_Simulation_Results.csv
    LNC_Hosting_Capacity_Summary.csv

RESEARCH LIMITATION
-------------------
This is a representative three-bus test feeder. It is not an actual KSEB
feeder and should be described as a representative/model-generated case in
the paper.

VUF
---
VUF is now calculated using symmetrical components:
    VUF = |V2|/|V1| * 100

This is more appropriate for a three-phase power-quality study than simply
using the maximum-minus-minimum phase-voltage magnitude spread.
