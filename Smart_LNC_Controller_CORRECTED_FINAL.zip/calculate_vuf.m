function VUF = calculate_vuf(V)
% CALCULATE_VUF
% Maximum negative-sequence voltage unbalance factor across buses.
%
% VUF = |V2| / |V1| * 100
%
% V must contain complex phase voltages with columns [A B C].

[nbus,nph] = size(V);

if nph ~= 3
    error('V must have three phase columns [A B C].');
end

a = exp(1j*2*pi/3);

VUF_bus = zeros(nbus,1);

for b = 1:nbus

    Va = V(b,1);
    Vb = V(b,2);
    Vc = V(b,3);

    V1 = (Va + a*Vb + a^2*Vc)/3;
    V2 = (Va + a^2*Vb + a*Vc)/3;

    if abs(V1) < 1e-12
        VUF_bus(b) = Inf;
    else
        VUF_bus(b) = 100*abs(V2)/abs(V1);
    end
end

VUF = max(VUF_bus);

end
