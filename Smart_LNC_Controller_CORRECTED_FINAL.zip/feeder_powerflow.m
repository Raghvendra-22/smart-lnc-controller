function [V,Ibranch] = feeder_powerflow(Pnet,Qnet,Zline)
% FEEDER_POWERFLOW
% Three-bus radial backward-forward sweep.
%
% Pnet and Qnet are bus power demands:
%   positive P = consumption
%   positive Q = reactive consumption
%
% PV convention used by the main program:
%   Qpv > 0 = reactive injection
%   Qpv < 0 = reactive absorption
%
% The net reactive demand is therefore:
%   Qnet = Qload - Qpv

[nbus,nph] = size(Pnet);

if nbus ~= 3 || nph ~= 3
    error('This feeder model requires a 3-bus, 3-phase matrix.');
end

% Positive-sequence phase reference at the source.
a = exp(1j*2*pi/3);
Vsource = [1, a^2, a];

% Initial bus voltages.
V = repmat(Vsource,nbus,1);

maxIter = 100;
tol = 1e-10;

for iter = 1:maxIter

    % Bus load currents.
    Sbus = Pnet + 1j*Qnet;
    Ibus = conj(Sbus ./ V);

    % Backward sweep.
    Ibranch = zeros(nbus,nph);

    Ibranch(3,:) = Ibus(3,:);
    Ibranch(2,:) = Ibus(2,:) + Ibranch(3,:);
    Ibranch(1,:) = Ibus(1,:) + Ibranch(2,:);

    % Forward sweep.
    Vnew = zeros(nbus,nph);

    Vnew(1,:) = Vsource - Zline .* Ibranch(1,:);
    Vnew(2,:) = Vnew(1,:) - Zline .* Ibranch(2,:);
    Vnew(3,:) = Vnew(2,:) - Zline .* Ibranch(3,:);

    if max(abs(Vnew(:)-V(:))) < tol
        V = Vnew;
        break;
    end

    V = Vnew;
end

if iter == maxIter
    warning('Power-flow reached maximum iterations before tolerance.');
end

end
